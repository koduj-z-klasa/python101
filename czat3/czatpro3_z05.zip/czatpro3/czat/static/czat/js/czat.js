<!--
$(document).ready(function(){
    $('.helptext').each(function(){
        var tekst = $(this).text();
        $(this).before('<div class="helptext">'+tekst+'</div>');
    });
    $('span.helptext').remove();
    $('.helptext').css("color", "red");
    $('.helptext').css("width", "350");
});
//-->
