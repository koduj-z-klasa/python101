# -*- coding: utf-8 -*-
# czat/czat/views.py

from django.http import HttpResponse


def index(request):
    """Strona główna aplikacji."""
    return HttpResponse("<h1>Witaj w aplikacji Czat!</h1>")
