# -*- coding: utf-8 -*-
# czatpro2/czat/urls.py

from django.conf.urls import url
from czat import views
from django.contrib.auth.forms import UserCreationForm
from django.views.generic.edit import CreateView
from django.core.urlresolvers import reverse_lazy

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^rejestruj/', CreateView.as_view(
        template_name='czat/rejestruj.html',
        form_class=UserCreationForm,
        success_url='/'), name='rejestruj'),
    url(r'^loguj/', 'django.contrib.auth.views.login',
        {'template_name': 'czat/loguj.html'},
        name='loguj'),
    url(r'^wyloguj/', 'django.contrib.auth.views.logout',
        {'next_page': reverse_lazy('czat:index')},
        name='wyloguj'),
]
