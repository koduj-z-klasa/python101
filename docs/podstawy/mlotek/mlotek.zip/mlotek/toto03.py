#!/usr/bin/env python
# -*- coding: utf-8 -*-

import random

liczba = random.randint(1, 10)
print "Wylosowana liczba:", liczba

odp = raw_input("Jaką liczbę od 1 do 10 mam na myśli? ")
