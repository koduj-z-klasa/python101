#! /usr/bin/env python
# -*- coding: utf-8 -*-

import random

liczba = random.randint(1, 10)
print "Wylosowana liczba:", liczba
