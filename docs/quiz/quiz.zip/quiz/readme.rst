Quiz – Aplikacja internetowa
============================

Realizacja aplikacji internetowej Quiz w oparciu o mikro-framework Flask.

Opis tego przykładu znajduje się w dokumentacji szkolenia:

http://python101.readthedocs.org/pl/latest/quiz/index.html
