# -*- coding: utf-8 -*-
# quiz/quiz.py

from flask import Flask
from flask import render_template

app = Flask(__name__)

# dekorator laczacy adres glowny z widokiem index
@app.route('/')

def index():
    # gdybyśmy chcieli wyświetlić prosty tekst, użyjemy funkcji poniżej
    #return 'Hello, SWOI'
    # zwracamy wyrenderowany szablon index.html:
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
