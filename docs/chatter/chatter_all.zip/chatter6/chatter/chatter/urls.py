from django.conf.urls import patterns, include, url
from django.contrib import admin
from chatter import views # importujemy zdefiniowane w pliku views.py widoki

admin.autodiscover()

urlpatterns = patterns('',
    # Examples:
    # url(r'^$', 'chatter.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),
    # glowny adres (/) o nazwie index laczymy z widokiem index
    url(r'^$', views.index, name='index'),
    # adres logowania (/login) o nazwie login powiazany z widokiem my_login
    url(r'^login/$', views.my_login, name='login'),
    url(r'^admin/', include(admin.site.urls)),
)
