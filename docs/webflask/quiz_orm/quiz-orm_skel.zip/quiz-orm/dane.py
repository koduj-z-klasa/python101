# -*- coding: utf-8 -*-
# quiz-orm/dane.py
