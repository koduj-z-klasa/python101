"""
mod1
"""

def func1(a, b):
    """
    this is func1
    """
    return a, b


class Class1(object):
    """
    this is Class1
    """
