# -*- coding: utf-8 -*-

project = 'Sphinx smallest project'
source_suffix = '.txt'
keep_warnings = True
