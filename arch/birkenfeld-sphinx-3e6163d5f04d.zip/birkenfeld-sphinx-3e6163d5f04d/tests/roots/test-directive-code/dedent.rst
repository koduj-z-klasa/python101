Dedent
======

Code blocks
-----------

.. code-block:: ruby
   :linenos:
   :dedent: 4

       def ruby?
           false
       end


Literal Include
---------------

.. literalinclude:: literal.inc
   :language: python
   :lines: 10-11
   :dedent: 4
