:tocdepth: 2

===
Bar
===

should be 2

Bar A
=====

should be 2.1

.. toctree::

   baz

Bar B
=====

should be 2.2

Bar B1
------

should be 2.2.1

